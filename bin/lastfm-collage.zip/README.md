Last.fm Collage
=============

Generates a collage of the art from a Last.fm user's most listened to albums

The Eclipse project's .classpath files expects json_simple-1.1's .class files in the /lib directory.

License
=============
Copyright (c) 2013 Greg Clark
MIT license, included in the LICENSE file